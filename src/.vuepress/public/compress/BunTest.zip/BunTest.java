package com.tsoft.bot.frontend.utility;

import com.tsoft.bot.frontend.helpers.BunEnv;
import cucumber.api.Scenario;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

/*
    Developer: Flavio Romero
*/
public class BunTest {

    private String feature;
    private String tags;
    private String scenario;
    private String estado;
    private String dateInicio;
    private String dateFin;
    private String time;

    public void setScenario(Scenario scenario) {
        String FEATURE = scenario.getId().split(";")[0].replace("-"," ");
        this.feature = FEATURE.substring(0, 1).toUpperCase() + FEATURE.substring(1);

        ArrayList<String> AUX_TAG = new ArrayList<>(scenario.getSourceTagNames());
        this.tags = Arrays.toString(AUX_TAG.toArray()).replace("[", "").replace("]", "");
        this.scenario = scenario.getName();
        this.estado = scenario.getStatus();
    }

    public void setDateInicio(long dateInicio) {
        Date dateInicioC = new Date();
        dateInicioC.setTime(dateInicio);
        this.dateInicio = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(dateInicioC);
    }

    public void setDateFin(long dateFin) {
        Date dateFinC = new Date();
        dateFinC.setTime(dateFin);
        this.dateFin = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(dateFinC);
    }

    public void setTime(double time) {
        this.time = String.valueOf(time/1000.0);
    }

    public void ExecutionResultTest() throws Throwable {
        HashMap<String, String> env = BunEnv.config();

        JSONObject data = new JSONObject();
        data.put(env.get("PARAM_1"), this.feature);
        data.put(env.get("PARAM_2"), this.scenario);
        data.put(env.get("PARAM_3"), this.tags);
        data.put(env.get("PARAM_4"), this.dateInicio);
        data.put(env.get("PARAM_5"), this.dateFin);
        data.put(env.get("PARAM_6"), this.time);
        data.put(env.get("PARAM_7"), this.estado);

        StringEntity entity;
        if (env.get("PARAM_BODY").isEmpty()){
            entity = new StringEntity(data.toJSONString());
        }else{
            JSONObject sendTest = new JSONObject();
            sendTest.put("data", data);
            entity = new StringEntity(sendTest.toJSONString());
        }

        if (BunEnv.PowerBunTest == true) {
            HttpPost request = new HttpPost(env.get("URL") + '/' + env.get("TABLE"));
            request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");

            if (env.get("HEADER_COUNT") != "0") {
                for (int i = 1; i < Integer.parseInt(env.get("HEADER_COUNT")) + 1; i++) {
                    request.setHeader(
                            env.get("HEADER_" + i),
                            env.get("HEADER_VAL_" + i)
                    );
                }
            }

            request.setEntity(entity);
            HttpClient httpClient = HttpClientBuilder.create().build();
            HttpResponse httpResponse = httpClient.execute(request);

            int status = httpResponse.getStatusLine().getStatusCode();
            System.out.println("[LOG] 🐾 Bun status code: " + status + " ❤");
        }else{
            System.out.println("[LOG] 💢 Bun status off 💔");
        }
    }
}
