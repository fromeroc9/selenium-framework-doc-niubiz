package com.tsoft.bot.frontend.helpers;

import java.util.HashMap;

public class BunEnv {
    public static Boolean PowerBunTest = false;

    public static HashMap<String, String> config() {
        HashMap<String, String> env = new HashMap<>();
        //CONFIG INICIAL
        env.put("URL", "https://zyqmcexcyyqjzkeuxiys.supabase.co/rest/v1");
        env.put("TABLE", "test");
        //CAMPOS TABLE
        env.put("PARAM_1", "feature");
        env.put("PARAM_2", "scenario");
        env.put("PARAM_3", "tag");
        env.put("PARAM_4", "dateInicio");
        env.put("PARAM_5", "dateFin");
        env.put("PARAM_6", "time");
        env.put("PARAM_7", "estado");
        //CONFIG EXTRA
        env.put("HEADER_COUNT", "2");
        env.put("HEADER_1", "apikey");
        env.put("HEADER_VAL_1", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp5cW1jZXhjeXlxanprZXV4aXlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NTc3MzE1NTYsImV4cCI6MTk3MzMwNzU1Nn0.kwwfkWWUQYFPBKQL9y7HL5_bLPcODqeyXjlDXgjfOwA");
        env.put("HEADER_2", "Authorization");
        env.put("HEADER_VAL_2", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp5cW1jZXhjeXlxanprZXV4aXlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NTc3MzE1NTYsImV4cCI6MTk3MzMwNzU1Nn0.kwwfkWWUQYFPBKQL9y7HL5_bLPcODqeyXjlDXgjfOwA");
        env.put("PARAM_BODY", ""); //EXCLUSIVO PARA STRAPI

        return env;
    }
}
